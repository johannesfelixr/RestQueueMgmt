package com.example.cobapplj;

public class Constants {
    public static final String server_addr = "192.168.100.8";
    public static final int server_port = 3456;
}
